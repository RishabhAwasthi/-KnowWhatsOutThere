package sugoi.noteclass;

import android.Manifest;
import android.app.Activity;
//PointF holds two float coordinates
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.icu.text.LocaleDisplayNames;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Telephony;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

import static java.lang.System.out;


public class MainActivity extends Activity{

    ImageView imageView;
    Button picker;
    String encodedImage;
    String path;
    File directory;
    File[] files;
    TextView textView;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView=(ImageView)findViewById(R.id.image);
        picker=(Button) findViewById(R.id.pick);
        textView=(TextView)findViewById(R.id.instr);
        Typeface face;

        face= Typeface.createFromAsset(getAssets(),"Quicksand-Regular.otf");

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            textView.setText(Html.fromHtml("<u><b>Steps to use:</u></b><br><br>\nStep1: Choose Directory by Clilcking on Classify.<br><br>\n\nStep2: Sitback and see the magic happen.",Html.FROM_HTML_MODE_COMPACT));
        } else {
            textView.setText(Html.fromHtml("<u><b>Steps to use:</u></b><br><br>\nStep1: Choose Directory by Clilcking on Classify.<br><br>\n\nStep2: Sitback and see the magic happen."));
        }
        textView.setTypeface(face);


        checkPermissionCW();
        checkPermissionCR();

        picker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
          Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                in.addCategory(Intent.CATEGORY_DEFAULT);
                startActivityForResult(Intent.createChooser(in, "Choose"),9999);


            }
        });








    }

    InputStream fileInputStream;
    byte[] bytes;
    String a;

    Thread th1;

    File[] listFile;
    File orderedFile;
    String move;


    public void getFromSdcard() throws InterruptedException {
        String root = Environment.getExternalStorageDirectory().getAbsolutePath()+"/";
        File createDir = new File(root+"Notes"+File.separator);
        if(!createDir.exists()) {
            createDir.mkdir();
        }
        File file= new File(path);
        Log.d("rishabhs path:",file.getAbsolutePath());
        if (file.isDirectory())
        {
            listFile = file.listFiles();

            for (int i = 0; i < listFile.length; i++) {


                try {

                    Log.d("Image path", listFile[i].getAbsolutePath());
                    fileInputStream = new FileInputStream(listFile[i].getAbsolutePath());


                    ByteArrayOutputStream output = new ByteArrayOutputStream();
                    int bytesRead;
                    byte[] buffer = new byte[8192];

                    while ((bytesRead = fileInputStream.read(buffer)) != -1) {
                        output.write(buffer, 0, bytesRead);
                    }


                    bytes = output.toByteArray();

                    encodedImage = Base64.encodeToString(bytes, Base64.DEFAULT);
                    Log.d("Image name:", listFile[i].getName());
                    Toast.makeText(getApplicationContext(), listFile[i].getName(), Toast.LENGTH_SHORT).show();
                    output.flush();
                    output.close();
                } catch (Exception e) {
                    //   Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                }
                orderedFile=listFile[i];
                performjson();
                th1.sleep(2000);








            }

            runOnUiThread(new Runnable() {
                public void run() {
                    Toast.makeText(getApplicationContext(),"Done collecting, DRACARYS!..., I've burnt it",Toast.LENGTH_LONG).show();
                }
            });




        }



        else
            Toast.makeText(getApplicationContext(),"File not found mate",Toast.LENGTH_SHORT).show();
    }

    public void encode_image(){



        th1 = new Thread(new Runnable(){
            public void run(){
                try {
                    getFromSdcard();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });





        th1.start();




    }


    ProgressDialog progress;


    JSONObject jsonObject;
            public void performjson(){
                 progress = new ProgressDialog(this);
                progress.setTitle("Loading");
                progress.setMessage("Wait while loading...");
                progress.setCancelable(false);
                try{
                    jsonObject = new JSONObject();
//                    Log.d("encoded_inJSON:",encodedImage);
                    jsonObject.put("data", encodedImage);}catch (Exception e){Toast.makeText(getApplicationContext(),"json eerror",Toast.LENGTH_SHORT).show();}
                Log.d("TAG3","In perform json");
                RequestQueue mQueue = Volley.newRequestQueue(getApplicationContext());
                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest("https://spamhealer-208004.appspot.com/predict",jsonObject,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                Log.d("TAG1", response.toString());

                                try {
                                    Toast.makeText(getApplicationContext(), response.getString("msg"), Toast.LENGTH_SHORT).show();
                                    move = response.getString("msg");
                                    if (move.equals("True")) {
                                        // your sd card
                                        String sdCard = Environment.getExternalStorageDirectory().toString();

                                        // the file to be moved or copied
                                        File sourceLocation = new File(orderedFile.getAbsolutePath());

                                        // make sure your target location folder exists!
                                        File targetLocation = new File(sdCard + "/Notes" + File.separator + orderedFile.getName());

                                        // just to take note of the location sources
                                        Log.d("SRC:", "sourceLocation: " + sourceLocation);
                                        Log.d("DEST:", "targetLocation: " + targetLocation);


                                        if (sourceLocation.renameTo(targetLocation)) {
                                            Log.d("Success:", "Move file successful.");
                                        } else {
                                            Log.d("Failed", "Move file failed.");
                                        }


                                    }

                                } catch (Exception e) {

                                }



                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.e("TAG", error.getMessage(), error);
                    }
                }) { //no semicolon or coma
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("Content-Type", "application/json");
                        return params;
                    }
                };
                mQueue.add(jsonObjectRequest);
        }



    private void checkPermissionCR() {
        int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 111);
        }
    }

    private void checkPermissionCW() {
        int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 112);
        }
    }


    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        switch (requestCode) {
            case 111:

                break;
            case 112:
                break;

        }
    }




    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case 9999:
                try {
                    Log.i("Test", "Result URI " + data.getData());
                    Toast.makeText(getApplicationContext(), "" + data.getData().getPath(), Toast.LENGTH_SHORT).show();
                    Log.d("path:", data.getData().getPath() + "");
                     path = FileUtil.getFullPathFromTreeUri(data.getData(),this);
                    encode_image();

                }catch (Exception e){}
                break;

        }

        }




}