package sugoi.noteclass;

import android.content.Intent;
import android.graphics.Typeface;
import android.media.Image;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashScreen extends AppCompatActivity {


    TextView textView;
    Button button;

    Animation frombottom,fromtop;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        textView=(TextView)findViewById(R.id.name);
        button=(Button)findViewById(R.id.click);
        imageView=(ImageView)findViewById(R.id.imgview);

        frombottom= AnimationUtils.loadAnimation(this,R.anim.frombottom);
        fromtop=AnimationUtils.loadAnimation(this,R.anim.fromtop);

        button.setAnimation(frombottom);
        textView.setAnimation(fromtop);
        imageView.setAnimation(fromtop);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(SplashScreen.this,MainActivity.class));

            }
        });

        Typeface face;

        face = Typeface.createFromAsset(getAssets(), "Lobster_1.3.otf");

        textView.setTypeface(face);


    }
}
